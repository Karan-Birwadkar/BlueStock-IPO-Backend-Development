from django.core.management.base import BaseCommand
from ipo.models import Company, IPO, Document
from datetime import date

class Command(BaseCommand):
    help = 'Load extended dummy data for IPO platform'

    def handle(self, *args, **kwargs):
        self.stdout.write("Clearing old data...")
        Document.objects.all().delete()
        IPO.objects.all().delete()
        Company.objects.all().delete()

        self.stdout.write("Creating companies...")
        c1 = Company.objects.create(company_name="Zomato Ltd")
        c2 = Company.objects.create(company_name="Nykaa Ltd")
        c3 = Company.objects.create(company_name="Paytm Ltd")
        c4 = Company.objects.create(company_name="Mamaearth Ltd")
        c5 = Company.objects.create(company_name="Ola Electric")
        c6 = Company.objects.create(company_name="Zepto Ltd")

        self.stdout.write("Creating IPOs...")
        ipo1 = IPO.objects.create(company=c1, open_date=date(2025, 7, 1), close_date=date(2025, 7, 4),
                                  price_band="72-76", lot_size=50, status="Upcoming")

        ipo2 = IPO.objects.create(company=c2, open_date=date(2025, 6, 10), close_date=date(2025, 6, 12),
                                  price_band="100-110", lot_size=30, status="Listed",
                                  listing_price=115, ipo_price=105, listing_date=date(2025, 6, 20))

        ipo3 = IPO.objects.create(company=c3, open_date=date(2025, 5, 5), close_date=date(2025, 5, 7),
                                  price_band="150-160", lot_size=20, status="Listed",
                                  listing_price=140, ipo_price=155, listing_date=date(2025, 5, 15))

        ipo4 = IPO.objects.create(company=c4, open_date=date(2025, 8, 15), close_date=date(2025, 8, 17),
                                  price_band="80-90", lot_size=40, status="Upcoming")

        ipo5 = IPO.objects.create(company=c5, open_date=date(2025, 9, 1), close_date=date(2025, 9, 5),
                                  price_band="90-100", lot_size=35, status="Upcoming")

        ipo6 = IPO.objects.create(company=c6, open_date=date(2025, 4, 1), close_date=date(2025, 4, 3),
                                  price_band="60-70", lot_size=45, status="Listed",
                                  listing_price=74, ipo_price=65, listing_date=date(2025, 4, 10))

        self.stdout.write("Creating Documents...")

        for ipo in [ipo1, ipo2, ipo3, ipo4, ipo5, ipo6]:
            Document.objects.create(
                ipo=ipo,
                rhp_pdf=f"https://example.com/{ipo.company.company_name.lower().replace(' ', '_')}_rhp.pdf",
                drhp_pdf=f"https://example.com/{ipo.company.company_name.lower().replace(' ', '_')}_drhp.pdf"
            )

        self.stdout.write(self.style.SUCCESS("Extended dummy data loaded successfully."))
