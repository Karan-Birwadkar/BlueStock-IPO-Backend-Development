from django.db import models


# ----------------------------
# Company Model
# ----------------------------
class Company(models.Model):
    company_name = models.CharField(max_length=255)
    company_logo = models.ImageField(upload_to='logos/', null=True, blank=True)

    def __str__(self):
        return self.company_name

    class Meta:
        verbose_name_plural = "Companies"


# ----------------------------
# IPO Model
# ----------------------------
class IPO(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='ipos')
    open_date = models.DateField()
    close_date = models.DateField()
    price_band = models.CharField(max_length=100)
    lot_size = models.IntegerField(default=1)
    status = models.CharField(max_length=50, default='Upcoming')
    listing_date = models.DateField(null=True, blank=True)
    ipo_price = models.FloatField(null=True, blank=True)
    listing_price = models.FloatField(null=True, blank=True)

    def listing_gain(self):
        if self.ipo_price and self.listing_price:
            return round(self.listing_price - self.ipo_price, 2)
        return None

    def current_return(self):
        if self.ipo_price and self.listing_price:
            return f"{round(((self.listing_price - self.ipo_price) / self.ipo_price) * 100, 2)}%"
        return "N/A"

    def __str__(self):
        return f"{self.company.company_name} IPO"


# ----------------------------
# Document Model
# ----------------------------
class Document(models.Model):
    ipo = models.ForeignKey(IPO, on_delete=models.CASCADE, related_name='documents')
    rhp_pdf = models.URLField()
    drhp_pdf = models.URLField()

    def __str__(self):
        return f"Documents for {self.ipo}"
