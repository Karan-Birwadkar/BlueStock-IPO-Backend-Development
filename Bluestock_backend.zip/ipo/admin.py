from django.contrib import admin
from django.contrib.admin import DateFieldListFilter
from django.utils.html import format_html
from .models import Company, IPO, Document


# Inline IPOs under Company admin
class IPOInline(admin.TabularInline):
    model = IPO
    extra = 1
    classes = ['collapse']
    show_change_link = True


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('company_name', 'logo_preview')
    search_fields = ('company_name',)
    inlines = [IPOInline]
    readonly_fields = ('logo_preview',)

    def logo_preview(self, obj):
        if obj.company_logo:
            return format_html(
                '<img src="{}" width="60" height="60" style="object-fit:contain; border-radius:6px;" />',
                obj.company_logo.url
            )
        return "No logo"
    logo_preview.short_description = "Logo"


@admin.register(IPO)
class IPOAdmin(admin.ModelAdmin):
    list_display = (
        'company',
        'status',
        'open_date',
        'listing_date',
        'formatted_ipo_price',
        'formatted_listing_price',
        'listing_gain',
        'current_return',
    )
    list_filter = (
        'status',
        ('open_date', DateFieldListFilter),
        ('listing_date', DateFieldListFilter),
    )
    search_fields = ('company__company_name',)
    readonly_fields = ('listing_gain', 'current_return')
    actions = ['mark_as_listed']

    def formatted_ipo_price(self, obj):
        return f"₹{obj.ipo_price:,.2f}" if obj.ipo_price is not None else "-"
    formatted_ipo_price.short_description = 'IPO Price'

    def formatted_listing_price(self, obj):
        return f"₹{obj.listing_price:,.2f}" if obj.listing_price is not None else "-"
    formatted_listing_price.short_description = 'Listing Price'

    def listing_gain(self, obj):
        return f"₹{obj.listing_gain():,.2f}" if obj.listing_gain() is not None else "-"
    listing_gain.short_description = "Listing Gain"

    def current_return(self, obj):
        return obj.current_return() if obj.current_return() is not None else "-"
    current_return.short_description = "Current Return"

    def mark_as_listed(self, request, queryset):
        updated = queryset.update(status='Listed')
        self.message_user(request, f"{updated} IPO(s) marked as listed.")
    mark_as_listed.short_description = "Mark selected IPOs as Listed"


@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = ('ipo', 'rhp_pdf', 'drhp_pdf')
    search_fields = ('ipo__company__company_name',)
