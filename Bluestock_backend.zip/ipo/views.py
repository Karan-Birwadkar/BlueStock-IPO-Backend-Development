from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticatedOrReadOnly

from .models import Company, IPO, Document
from .serializers import CompanySerializer, IPOSerializer, DocumentSerializer


# ----------------------------
# API ViewSets (for DRF Router)
# ----------------------------

class CompanyViewSet(viewsets.ModelViewSet):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer
    permission_classes = [IsAuthenticatedOrReadOnly]


class IPOViewSet(viewsets.ModelViewSet):
    queryset = IPO.objects.all()
    serializer_class = IPOSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]


class DocumentViewSet(viewsets.ModelViewSet):
    queryset = Document.objects.all()
    serializer_class = DocumentSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]


# ----------------------------
# Admin Dashboard View
# ----------------------------

@login_required(login_url='/login/')
def admin_dashboard(request):
    total_ipos = IPO.objects.count()
    upcoming_ipos = IPO.objects.filter(status='Upcoming').count()
    listed_ipos = IPO.objects.filter(status='Listed').count()

    company_ipos = Company.objects.all().prefetch_related('ipos')

    context = {
        'total_ipos': total_ipos,
        'upcoming_ipos': upcoming_ipos,
        'listed_ipos': listed_ipos,
        'company_ipos': company_ipos,
    }

    return render(request, 'admin/dashboard.html', context)


# ----------------------------
# Homepage View
# ----------------------------

def home(request):
    return render(request, 'home.html')


# ----------------------------
# Signup View
# ----------------------------

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('/')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})
