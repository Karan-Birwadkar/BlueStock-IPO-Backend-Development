from rest_framework import serializers
from .models import Company, IPO, Document

class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['id', 'rhp_pdf', 'drhp_pdf']

class IPOSerializer(serializers.ModelSerializer):
    documents = DocumentSerializer(many=True, read_only=True)
    company_name = serializers.CharField(source='company.company_name', read_only=True)

    class Meta:
        model = IPO
        fields = [
            'id', 'company', 'company_name', 'open_date', 'close_date',
            'price_band', 'lot_size', 'status', 'listing_date',
            'ipo_price', 'listing_price', 'documents'
        ]

class CompanySerializer(serializers.ModelSerializer):
    ipos = IPOSerializer(many=True, read_only=True)
    logo_url = serializers.SerializerMethodField()

    class Meta:
        model = Company
        fields = ['id', 'company_name', 'logo_url', 'ipos']

    def get_logo_url(self, obj):
        request = self.context.get('request')
        if obj.company_logo:
            return request.build_absolute_uri(obj.company_logo.url) if request else obj.company_logo.url
        return None
