
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from django.contrib.auth import views as auth_views
from .views import (
    CompanyViewSet,
    IPOViewSet,
    DocumentViewSet,
    admin_dashboard,
    signup_view,
)

# Register API viewsets
router = DefaultRouter()
router.register(r'companies', CompanyViewSet, basename='companies')
router.register(r'ipos', IPOViewSet, basename='ipos')
router.register(r'documents', DocumentViewSet, basename='documents')

urlpatterns = router.urls + [
    # Admin dashboard view
    path('dashboard/', admin_dashboard, name='admin_dashboard'),

    # Auth pages
    path('signup/', signup_view, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),
]
